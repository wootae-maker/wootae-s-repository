﻿#include<bangtal.h>
#pragma comment(lib, "bangtal.lib")


SceneID scene1;
ObjectID startButton, restartButton, endButton;


void mousetCallback(ObjectID object, int x, int y, MouseAction action) {
	if (object == startButton) {
		hideObject(startButton);
		hideObject(endButton);
		showObject(restartButton);

	}

	else if (object == endButton) {
		endGame();
	}

	else if (object == restartButton) {
		hideObject(restartButton);
		showObject(startButton);
		showObject(endButton);

	}
}

int main() {
	setMouseCallback(mousetCallback);
	
	
	scene1 = createScene("퍼즐맞추기", "images/중앙대.png");

	

	startButton = createObject("images/start.png");
	locateObject(startButton, scene1, 590, 90);
	showObject(startButton);

	endButton = createObject("images/end.png");
	locateObject(endButton, scene1, 590, 40);
	showObject(endButton);

	restartButton = createObject("images/restart.png");
	locateObject(restartButton, scene1, 590, 65);
	


	startGame(scene1);
}